package Controller;

import Exceptions.InterprException;
import model.PrgState;
import model.Statement.*;
import repository.IPrgStateRepo;
import utilities.IDictionary;
import utilities.IHeap;
import utilities.IStack;
import javafx.scene.control.Button;

import java.io.IOException;
import java.io.StreamCorruptedException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class controller {
    private IPrgStateRepo repo;
    private ExecutorService executor;

    public controller(IPrgStateRepo repo) {
        this.repo = repo;
        executor = Executors.newFixedThreadPool(2);

    }

    public List<PrgState> removeCompletedPrgStates(List<PrgState> states)
    {
        List<PrgState> newStates = states.stream().filter(prg -> prg.isNotCompleted()).collect(Collectors.toList());
        if(newStates.size() == 0)
        {
            states.forEach(state -> repo.logPrgStateExec(state));
            executor.shutdown();
        }
        return newStates;
    }

    public void oneStepForAllPrgs(List<PrgState> states)
    {
        states.forEach(prg -> repo.logPrgStateExec(prg));
        repo.setPrgList(states);

        List<Callable<PrgState>> callList = states.stream()
                .map((PrgState prg) -> (Callable<PrgState>)(() -> {return prg.executeOneStep();}))
                .collect(Collectors.toList());

        try {
            List<PrgState> newPrgList = executor.invokeAll(callList).stream()
                    .map(future -> {
                        try {
                            return future.get();
                        } catch (Exception ex) {
                            System.out.println(ex.toString());
                        }
                        return null;}).filter(prg -> prg != null).collect(Collectors.toList());

            states.addAll(newPrgList);
            repo.setPrgList(states);

        }
        catch (Exception ex)
        {
            System.out.println(ex.toString());
        }
    }

    public IPrgStateRepo getRepo() {
        return repo;
    }

    public Map<Integer,Integer> conservativeGarbageCollector(Collection<Integer> symTableValues, Map<Integer,Integer> heap){
        return heap.entrySet().stream()
                .filter(e->symTableValues.contains(e.getKey()))
                .collect(Collectors.toMap(e->e.getKey(), e->e.getValue()));
    }

    public List<PrgState> getProgramStates()
    {
        return repo.getPrgList();
    }

    public void executeAll()
    {
        executor = Executors.newFixedThreadPool(2);
        List<PrgState> states = removeCompletedPrgStates(repo.getPrgList());
        states.forEach(prg -> repo.logPrgStateExec(prg));
        states.forEach(prg -> System.out.println(prg));
        while(states.size()>0)
        {
            oneStepForAllPrgs(states);
            states.forEach(prg -> repo.logPrgStateExec(prg));
            states.forEach(prg -> System.out.println(prg));
            states = removeCompletedPrgStates(repo.getPrgList());

        }

        executor.shutdown();
        repo.setPrgList(states);
    }
}
