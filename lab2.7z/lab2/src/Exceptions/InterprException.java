package Exceptions;

public class InterprException extends RuntimeException {
    public InterprException(String message)
    {
        super(message);
    }
}
