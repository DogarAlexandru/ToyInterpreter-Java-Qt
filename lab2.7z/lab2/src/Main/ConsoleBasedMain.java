package Main;

import Controller.*;
import View.ExampleCommand;
import View.ExitCommand;
import View.textMenu;
import model.*;
import model.Expression.ArithmeticExpr;
import model.Expression.ConstExpr;
import model.Expression.VarExpr;
import model.FileStatement.*;

import model.*;
import model.HeapStatement.newH;
import model.HeapStatement.rH;
import model.HeapStatement.wH;
import model.Statement.*;
import repository.IPrgStateRepo;
import repository.PrgStateRepository;
import utilities.*;

import java.util.ArrayList;
import java.util.List;

public class ConsoleBasedMain
{
    public static void main(String arg[])
    {
        Statement s1=new CompStatement(new AssignStatement("v",new ConstExpr(2)), new PrintStatement(new
                VarExpr("v")));
        PrgState pr1=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s1,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep1=new PrgStateRepository("log.txt");
        rep1.addPrgState(pr1);
        controller con1=new controller(rep1);

        Statement s2=new CompStatement(new openRFile("var_f","test.in"),
            new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),
                    new CompStatement(new PrintStatement(new VarExpr("var_c")),
                            new CompStatement(new IfStatement(new VarExpr("var_c"),new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),new PrintStatement(new VarExpr("var_c"))),new PrintStatement(new ConstExpr(0))),
                                    new closeRFile(new VarExpr("var_f"))))));

        PrgState pr2=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s2,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep2=new PrgStateRepository("log2.txt");
        rep2.addPrgState(pr2);
        controller con2=new controller(rep2);

        Statement s3=new CompStatement(new openRFile("var_f","test.in"),
                new CompStatement(new readFile(new ArithmeticExpr("+",new VarExpr("var_f"),new ConstExpr(2)),"var_c"),
                        new CompStatement(new PrintStatement(new VarExpr("var_c")),
                                new CompStatement(new IfStatement(new VarExpr("var_c"),new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),new PrintStatement(new VarExpr("var_c"))),new PrintStatement(new ConstExpr(0))),
                                        new closeRFile(new VarExpr("var_f"))))));

        PrgState pr3=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s3,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep3=new PrgStateRepository("log3.txt");
        rep3.addPrgState(pr3);
        controller con3=new controller(rep3);


        Statement s4=new CompStatement(new AssignStatement("a", new ArithmeticExpr("-",new ConstExpr(2), new
                ConstExpr(2))),
                new CompStatement(new IfStatement(new VarExpr("a"),new AssignStatement("v",new ConstExpr(2)), new
                        AssignStatement("v", new ConstExpr(3))), new PrintStatement(new VarExpr("v"))));

        PrgState pr4=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s4,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep4=new PrgStateRepository("log4.txt");
        rep4.addPrgState(pr4);
        controller con4=new controller(rep4);

        //v=10;new(v,20);new(a,22);wH(a,30);print(a);print(rH(a));a=0


        Statement s5=new CompStatement(new AssignStatement("v",new ConstExpr(10)),
                new CompStatement(new newH("v",new ConstExpr(20)),
                        new CompStatement(new newH("a",new ConstExpr(22)),
                                new CompStatement(new wH("a",new ConstExpr(30)),
                                        new CompStatement(new PrintStatement(new VarExpr("a")),
                                                new CompStatement(new PrintStatement(new rH("a")),
                                                        new AssignStatement("a",new ConstExpr(0))))))));

        PrgState pr5=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s5,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep5=new PrgStateRepository("log5.txt");
        rep5.addPrgState(pr5);
        controller con5=new controller(rep5);

        Statement s6=new CompStatement(new openRFile("var_f","test.in"),
                new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),
                        new CompStatement(new PrintStatement(new VarExpr("var_c")),
                                new IfStatement(new VarExpr("var_c"),new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),new PrintStatement(new VarExpr("var_c"))),new PrintStatement(new ConstExpr(0))))));

        PrgState pr6=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s6,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep6=new PrgStateRepository("log6.txt");
        rep6.addPrgState(pr6);
        controller con6=new controller(rep6);

        //v=6; (while (v-4) print(v);v=v-1);print(v)

        Statement s7=new CompStatement(new AssignStatement("v",new ConstExpr(6)),
                new CompStatement(new WhileStatement(new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(4)),
                        new CompStatement(new PrintStatement(new VarExpr("v")),new AssignStatement("v",new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(1))))),
                            new PrintStatement(new VarExpr("v"))));
        PrgState pr7=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s7,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep7=new PrgStateRepository("log7.txt");
        rep7.addPrgState(pr7);
        controller con7=new controller(rep7);
        
        
        Statement s8=new CompStatement( new AssignStatement("v",new ConstExpr(10)),
                new CompStatement( new newH("a",new ConstExpr(22)),
                        new CompStatement(
                                new forkStatement( new CompStatement(
                                        new wH("a",new ConstExpr(30)),
                                        new CompStatement(
                                                new AssignStatement("v",new ConstExpr(32)),
                                                new CompStatement(
                                                        new PrintStatement(new VarExpr("v")),
                                                        new PrintStatement(new rH("a")))))),
                                new CompStatement(new PrintStatement(new VarExpr("v")),new PrintStatement(new rH("a"))))));
        PrgState pr8=new PrgState(new ExecStack<>(),new Dictionary<>(),new OutputList<>(),s8,new FileTable<>(),new Heap<>());
        IPrgStateRepo rep8=new PrgStateRepository("log8.txt");
        rep8.addPrgState(pr8);
        controller con8=new controller(rep8);

        textMenu t=new textMenu();
        t.addCommand(new ExitCommand("0","Exit"));
        t.addCommand(new ExampleCommand("1",s1.toString(),con1));
        t.addCommand(new ExampleCommand("2",s2.toString(),con2));
        t.addCommand(new ExampleCommand("3",s3.toString(),con3));
        t.addCommand(new ExampleCommand("4",s4.toString(),con4));
        t.addCommand(new ExampleCommand("5",s5.toString(),con5));
        t.addCommand(new ExampleCommand("6",s6.toString(),con6));
        t.addCommand(new ExampleCommand("7",s7.toString(),con7));
        t.addCommand(new ExampleCommand("8",s8.toString(),con8));

        t.show();

    }
}
