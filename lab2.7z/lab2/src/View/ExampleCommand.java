package View;

import Controller.controller;

public class ExampleCommand extends Command {
    private controller c;
    public ExampleCommand(String k,String d,controller cn)
    {
        super(k,d);
        c=cn;
    }
    public void execute()
    {
        c.executeAll();
    }

}
