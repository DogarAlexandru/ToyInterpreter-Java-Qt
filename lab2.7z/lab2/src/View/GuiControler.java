package View;

import Controller.controller;
import model.*;
import model.Expression.ArithmeticExpr;
import model.Expression.ConstExpr;
import model.Expression.VarExpr;
import model.FileStatement.openRFile;
import model.FileStatement.readFile;
import model.HeapStatement.newH;
import model.HeapStatement.rH;
import model.HeapStatement.wH;
import model.Statement.*;
import repository.*;
import utilities.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class GuiControler {
    private controller ctrl;
    IStack<Statement> stack = new ExecStack<Statement>();
    IDictionary<String,Integer> dict = new Dictionary<>();
    IList<Integer> outputList = new OutputList<>();
    IFileTable<Integer,fileTuple> fileTable = new FileTable<>();
    IHeap<Integer,Integer> heap = new Heap<>();

    @FXML
    public ListView<Statement> prgStatesList;
    public Label nrStates;
    public ListView<Integer> prgStates;
    public ListView<Statement> exeStack;
    public ListView<Integer> outList;


    public TableView<SymbolTableDataFX> symTable;
    public TableColumn<SymbolTableDataFX,String> varName;
    public TableColumn<SymbolTableDataFX,Integer> value;

    public TableView<HeapDataFX> heapTable;
    public TableColumn<HeapDataFX,Integer> heapAddress;
    public TableColumn<HeapDataFX,Integer> heapValue;

    public TableView<FileTableDataFX> filetableTable;
    public TableColumn<FileTableDataFX,Integer> identifier;
    public TableColumn<FileTableDataFX,String> filename;


    @FXML
    public void oneStep(ActionEvent event)
    {
        try
        {
            ctrl.oneStepForAllPrgs(this.ctrl.removeCompletedPrgStates(this.ctrl.getRepo().getPrgList()));
            //this.ctrl.justExecuteOneStep();
            initializeAll();
            List<PrgState> states =this.ctrl.removeCompletedPrgStates(this.ctrl.getRepo().getPrgList());
            this.ctrl.getRepo().setPrgList(states);

            initializePrgState();
        }
        catch(Exception ex)
        {
            System.out.println(ex.toString()+" - oneStepBtn");
        }
    }

    @FXML
    public void initialize()
    {
        //   v=10;
        //(fork(v=v-1;v=v-1;print(v)); sleep(10);print(v*10)
        //  The final Out should be {8,100}
        Statement s1=new CompStatement(
                        new AssignStatement("v",new ConstExpr(10)),
                            new CompStatement(
                                    new forkStatement(
                                            new CompStatement(
                                                    new CompStatement(
                                                            new AssignStatement("v",new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(1))),
                                                            new AssignStatement("v",new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(1)))
                                                    ),
                                                    new PrintStatement(new VarExpr("v"))
                                            )
                                    ),
                                    new CompStatement(
                                            new SleepStatement(10),
                                            new PrintStatement(new ArithmeticExpr("*",new VarExpr("v"),new ConstExpr(10)))
                                    )
                            ));

        Statement s2=new CompStatement(new AssignStatement("v",new ConstExpr(6)),
                new CompStatement(new WhileStatement(new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(4)),
                        new CompStatement(new PrintStatement(new VarExpr("v")),new AssignStatement("v",new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(1))))),
                        new PrintStatement(new VarExpr("v"))));

        Statement s3=new CompStatement(new openRFile("var_f","test.in"),
                new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),
                        new CompStatement(new PrintStatement(new VarExpr("var_c")),
                                new IfStatement(new VarExpr("var_c"),new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),new PrintStatement(new VarExpr("var_c"))),new PrintStatement(new ConstExpr(0))))));


        Statement s4=new CompStatement(new AssignStatement("v",new ConstExpr(10)),
                new CompStatement(new newH("v",new ConstExpr(20)),
                        new CompStatement(new newH("a",new ConstExpr(22)),
                                new CompStatement(new wH("a",new ConstExpr(30)),
                                        new CompStatement(new PrintStatement(new VarExpr("a")),
                                                new CompStatement(new PrintStatement(new rH("a")),
                                                        new AssignStatement("a",new ConstExpr(0))))))));



        ObservableList<Statement> stmts = FXCollections.observableArrayList(s1,s2,s3,s4);
        prgStatesList.setItems(stmts);
        prgStatesList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        prgStatesList.getSelectionModel().selectIndices(0);
        prgStatesList.getFocusModel().focus(0);
        prgStatesList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Statement>()
        {

            @Override
            public void changed(ObservableValue<? extends Statement> observable, Statement oldValue, Statement newValue) {
                initializeExecution(newValue);
                initializeAll();
            }
        });

        initializeExecution(s1);
        initializeAll();
    }

    public void initializeExecution(Statement stmt)
    {
        stack.clear();
        dict.clear();
        outputList.clear();
        fileTable.clear();
        heap.clear();

        stack.push(stmt);
        PrgState prg1 = new PrgState(stack,dict,outputList,stmt,fileTable,heap);
        IPrgStateRepo  repo1 = new PrgStateRepository("log.txt");
        repo1.addPrgState(prg1);
        this.ctrl = new controller(repo1);
    }

    public void initializeAll()
    {
        initializePrgState();
        initializeOutputList();
        initializeHeapTable();
        initializeFileTable();
    }

    public void initializePrgState()
    {
        List<PrgState> states = this.ctrl.getRepo().getPrgList();
        ObservableList<Integer> programs = FXCollections.observableArrayList();

        for(int i=0;i<states.size();i++)
            programs.add(i);

        prgStates.setItems(programs);
        prgStates.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        prgStates.getSelectionModel().selectIndices(0);
        prgStates.getFocusModel().focus(2);

        prgStates.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Integer>()
        {
            @Override
            public void changed(ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue)
            {
                initializeExeStack();
                initializeSymbolTable();
                nrStates.setText("Number of program states: " + ctrl.getRepo().getPrgList().size());
            }
        });
    }

    public void initializeOutputList()
    {
        try {
            if(this.ctrl.getProgramStates().size()>0)
            {
                ObservableList<Integer> observable = FXCollections.observableArrayList();
                IList<Integer> items = this.ctrl.getProgramStates().get(0).getMessages();
                for (Integer elem : items.getAll())
                    observable.add(elem);
                if (items != null && outList != null)
                    outList.setItems(observable);
            }
        }
        catch(Exception ex)
        {
            System.out.println(ex.toString() + "Initialize output list!");
        }
    }

    public void initializeExeStack()
    {
        try
        {
            int idx = prgStates.getSelectionModel().getSelectedItem();
            ObservableList<Statement> observable = FXCollections.observableArrayList();
            IStack<Statement> items = this.ctrl.getProgramStates().get(idx).getExecStack();

            for(Statement elem : items.getAll() )
                observable.add(elem);

            if (items != null && exeStack != null)
                exeStack.setItems(observable);
        }
        catch(Exception ex)
        {
            // System.out.println(ex.toString() + " - Initialize exe stack!");
        }
    }

    public void initializeSymbolTable()
    {
        try
        {
            int idx = prgStates.getSelectionModel().getSelectedItem();
            ObservableList<SymbolTableDataFX> observable = FXCollections.observableArrayList();
            IDictionary<String,Integer> items = this.ctrl.getProgramStates().get(idx).getSymbolT();

            for(Map.Entry<String,Integer> elem : items.entrySet() )
            {
                observable.add(new SymbolTableDataFX(elem.getKey(), elem.getValue()));
            }

            value.setCellValueFactory( fileTableData -> fileTableData.getValue().valueProperty().asObject() );
            varName.setCellValueFactory( fileTableData -> fileTableData.getValue().varNameProperty() );

            if (items != null && symTable != null)
                symTable.setItems(observable);
        }
        catch(Exception ex)
        {
            // System.out.println(ex.toString() + " - Initialize symbol table!");
        }
    }

    public void initializeHeapTable()
    {
        try
        {
            if(this.ctrl.getProgramStates().size()>0) {
                ObservableList<HeapDataFX> observable = FXCollections.observableArrayList();
                IHeap<Integer, Integer> items = this.ctrl.getProgramStates().get(0).getHeap();

                for (Map.Entry<Integer, Integer> elem : items.entrySet()) {
                    observable.add(new HeapDataFX(elem.getKey(), elem.getValue()));
                }

                heapValue.setCellValueFactory(fileTableData -> fileTableData.getValue().valueProperty().asObject());
                heapAddress.setCellValueFactory(fileTableData -> fileTableData.getValue().addressProperty().asObject());

                if (items != null && heapTable != null)
                    heapTable.setItems(observable);
            }
        }
        catch(Exception ex)
        {
            System.out.println(ex.toString() + "Initialize heap table!");
        }
    }

    public void initializeFileTable() {
        if (this.ctrl.getProgramStates().size() > 0) {
            ObservableList<FileTableDataFX> observable = FXCollections.observableArrayList();
            IFileTable<Integer, fileTuple> items = this.ctrl.getRepo().getPrgList().get(0).getFileT();

            for (Integer key : items.getKeys())
                observable.add(new FileTableDataFX(key, items.get(key).getFileName()));

            identifier.setCellValueFactory(fileTableData -> fileTableData.getValue().identifierProperty().asObject());
            filename.setCellValueFactory(fileTableData -> fileTableData.getValue().filenameProperty());


            if (items != null && filetableTable != null)
                filetableTable.setItems(observable);
        }
    }
}

