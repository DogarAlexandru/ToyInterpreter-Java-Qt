package View;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class HeapDataFX
{
    private IntegerProperty address;
    private IntegerProperty value;

    public HeapDataFX() {
        this.address = new SimpleIntegerProperty();
        this.value = new SimpleIntegerProperty();
    }

    public HeapDataFX(Integer address,Integer value) {
        this.address = new SimpleIntegerProperty();
        this.value = new SimpleIntegerProperty();

        this.address.setValue(address);
        this.value.setValue(value);
    }

    public int getValue() {
        return value.get();
    }

    public IntegerProperty valueProperty() {
        return value;
    }

    public void setValue(int value) {
        this.value.set(value);
    }

    public int getAddress() {
        return address.get();
    }

    public IntegerProperty addressProperty() {
        return address;
    }

    public void setAddress(int address) {
        this.address.set(address);
    }

}




