package View;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SymbolTableDataFX
{
    private StringProperty varName;
    private IntegerProperty value;

    public SymbolTableDataFX() {
        this.varName = new SimpleStringProperty();
        this.value = new SimpleIntegerProperty();
    }

    public SymbolTableDataFX(String varName,Integer value) {
        this.varName = new SimpleStringProperty();
        this.value = new SimpleIntegerProperty();

        this.varName.setValue(varName);
        this.value.setValue(value);
    }

    public int getValue() {
        return value.get();
    }

    public IntegerProperty valueProperty() {
        return value;
    }

    public void setValue(int value) {
        this.value.set(value);
    }

    public String getVarName() {
        return varName.get();
    }

    public StringProperty varNameProperty() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName.set(varName);
    }

}




