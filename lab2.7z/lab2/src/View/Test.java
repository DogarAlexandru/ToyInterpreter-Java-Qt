package View;

import Controller.controller;
import model.*;
import model.Expression.ArithmeticExpr;
import model.Expression.ConstExpr;
import model.Expression.VarExpr;
import model.FileStatement.openRFile;
import model.FileStatement.readFile;
import model.HeapStatement.newH;
import model.HeapStatement.rH;
import model.HeapStatement.wH;
import model.Statement.*;
import repository.*;
import utilities.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Test {
    private controller con;
    IStack<Statement> stack = new ExecStack<>();
    IDictionary<String,Integer> dict = new Dictionary<>();
    IList<Integer> outlist = new OutputList<>();
    IFileTable<Integer,fileTuple> fltable = new FileTable<>();
    IHeap<Integer,Integer> heap = new Heap<>();

    @FXML
    public ListView<Statement> options;

    public ListView<Statement> execv;

    public ListView<Integer> outlistv;

    public ListView<Integer> prgsv ;

    public Label nrlabel;

    public TableView<SymbolTableDataFX> symTable;

    public TableColumn<SymbolTableDataFX,String> varName;

    public TableColumn<SymbolTableDataFX,Integer> value;

    public TableView<HeapDataFX> heapTable;

    public TableColumn<HeapDataFX,Integer> heapAddress;

    public TableColumn<HeapDataFX,Integer> heapValue;

    public TableView<FileTableDataFX> filetableTable;

    public TableColumn<FileTableDataFX,Integer> identifier;

    public TableColumn<FileTableDataFX,String> filename;
    
    @FXML

    public void oneStep(ActionEvent event)
    {
        try
        {
            System.out.println(this.con.removeCompletedPrgStates(this.con.getRepo().getPrgList()));

            //con.oneStepForAllPrgs(this.con.removeCompletedPrgStates(this.con.getRepo().getPrgList()));
            initializeEverything();
           // List<PrgState> states =this.con.removeCompletedPrgStates(this.con.getRepo().getPrgList());
          //  this.con.getRepo().setPrgList(states);
            initializePrgStates();
           // this.con.justExecuteOneStep();
        }
        catch(Exception ex)
        {
            System.out.println(ex.toString()+" - oneStepBtn");
        }
    }

    @FXML

    public void initialize()
    {
        Statement s1=new CompStatement( new AssignStatement("v",new ConstExpr(10)),
                new CompStatement( new newH("a",new ConstExpr(22)),
                        new CompStatement(
                                new forkStatement( new CompStatement(
                                        new wH("a",new ConstExpr(30)),
                                        new CompStatement(
                                                new AssignStatement("v",new ConstExpr(32)),
                                                new CompStatement(
                                                        new PrintStatement(new VarExpr("v")),
                                                        new PrintStatement(new rH("a")))))),
                                new CompStatement(new PrintStatement(new VarExpr("v")),new PrintStatement(new rH("a"))))));
        Statement s2=new CompStatement(new AssignStatement("v",new ConstExpr(6)),
                new CompStatement(new WhileStatement(new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(4)),
                        new CompStatement(new PrintStatement(new VarExpr("v")),new AssignStatement("v",new ArithmeticExpr("-",new VarExpr("v"),new ConstExpr(1))))),
                        new PrintStatement(new VarExpr("v"))));

        Statement s3=new CompStatement(new openRFile("var_f","test.in"),
                new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),
                        new CompStatement(new PrintStatement(new VarExpr("var_c")),
                                new IfStatement(new VarExpr("var_c"),new CompStatement(new readFile(new VarExpr("var_f"),"var_c"),new PrintStatement(new VarExpr("var_c"))),new PrintStatement(new ConstExpr(0))))));


        Statement s4=new CompStatement(new AssignStatement("v",new ConstExpr(10)),
                new CompStatement(new newH("v",new ConstExpr(20)),
                        new CompStatement(new newH("a",new ConstExpr(22)),
                                new CompStatement(new wH("a",new ConstExpr(30)),
                                        new CompStatement(new PrintStatement(new VarExpr("a")),
                                                new CompStatement(new PrintStatement(new rH("a")),
                                                        new AssignStatement("a",new ConstExpr(0))))))));

        ObservableList<Statement> stm = FXCollections.observableArrayList(s1,s2,s3,s4);
        options.setItems(stm);
        options.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        options.getSelectionModel().selectIndices(0);
        options.getFocusModel().focus(2);
        options.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Statement>()
        {

            @Override
            public void changed(ObservableValue<? extends Statement> observable, Statement oldValue, Statement newValue) {
                initializeProgram(newValue);
                initializeEverything();
            }
        });

        initializeProgram(s1);
       // System.out.println(this.con.removeCompletedPrgStates(this.con.getRepo().getPrgList()));
        initializeEverything();
      //  System.out.println(this.con.removeCompletedPrgStates(this.con.getRepo().getPrgList()));



    }

    public void initializeProgram(Statement stmt)
    {
        stack.clear();
        dict.clear();
        outlist.clear();
        fltable.clear();
        heap.clear();


        PrgState prg1 = new PrgState(stack,dict,outlist,stmt,fltable,heap);
        IPrgStateRepo  repo1 = new PrgStateRepository("log.txt");
        repo1.addPrgState(prg1);
        this.con = new controller(repo1);
    }

    public void initializeEverything()
    {
       initializePrgStates();
       initializeOutputList();
       initializeHeapTable();
       initializeFileTable();
    }


    public void initializePrgStates()
    {
        List<PrgState> states = this.con.getRepo().getPrgList();
        ObservableList<Integer> programs = FXCollections.observableArrayList();

        for(int i=0;i<states.size();i++)
            programs.add(i);

        prgsv.setItems(programs);
        prgsv.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        prgsv.getSelectionModel().selectIndices(0);
        prgsv.getFocusModel().focus(2);
        prgsv.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Integer>()
        {
            @Override
            public void changed(ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue)
            {
                initializeExeStack();
                initializeSymbolTable();
                nrlabel.setText("Number of program states: " + con.getRepo().getPrgList().size());
            }
        });


    }
    
    public void initializeOutputList()
    {
        try {
            if(this.con.getProgramStates().size()>0)
            {
                ObservableList<Integer> observable = FXCollections.observableArrayList();
                IList<Integer> items = this.con.getProgramStates().get(0).getMessages();
                for (Integer elem : items.getAll())
                    observable.add(elem);
                if (items != null && outlistv != null)
                    outlistv.setItems(observable);
            }
        }
        catch(Exception ex)
        {
            System.out.println(ex.toString() + "Initialize output list!");
        }
    }

    public void initializeExeStack()
    {
        try
        {
            int idx = prgsv.getSelectionModel().getSelectedItem();
            ObservableList<Statement> observable = FXCollections.observableArrayList();
            IStack<Statement> items = this.con.getProgramStates().get(idx).getExecStack();

           for(Statement elem : items.getAll() )
              observable.add(elem);

           if (items != null && execv != null)
                execv.setItems(observable);
        }
        catch(Exception ex)
        {
            //System.out.println(ex.toString() + " - Initialize exe stack!");
        }
    }


    public void initializeSymbolTable()
    {
        try
        {
            int idx = prgsv.getSelectionModel().getSelectedItem();
            ObservableList<SymbolTableDataFX> observable = FXCollections.observableArrayList();
            IDictionary<String,Integer> items = this.con.getProgramStates().get(idx).getSymbolT();

            for(Map.Entry<String,Integer> elem : items.entrySet() )
            {
                observable.add(new SymbolTableDataFX(elem.getKey(), elem.getValue()));
            }

            value.setCellValueFactory( fileTableData -> fileTableData.getValue().valueProperty().asObject() );
            varName.setCellValueFactory( fileTableData -> fileTableData.getValue().varNameProperty() );

            if (items != null && symTable != null)
                symTable.setItems(observable);
        }
        catch(Exception ex)
        {
            // System.out.println(ex.toString() + " - Initialize symbol table!");
        }
    }

    public void initializeHeapTable()
    {
        try
        {
            if(this.con.getProgramStates().size()>0) {
                ObservableList<HeapDataFX> observable = FXCollections.observableArrayList();
                IHeap<Integer, Integer> items = this.con.getProgramStates().get(0).getHeap();

                for (Map.Entry<Integer, Integer> elem : items.entrySet()) {
                    observable.add(new HeapDataFX(elem.getKey(), elem.getValue()));
                }

                heapValue.setCellValueFactory(fileTableData -> fileTableData.getValue().valueProperty().asObject());
                heapAddress.setCellValueFactory(fileTableData -> fileTableData.getValue().addressProperty().asObject());

                if (items != null && heapTable != null)
                    heapTable.setItems(observable);
            }
        }
        catch(Exception ex)
        {
            System.out.println(ex.toString() + "Initialize heap table!");
        }
    }

    public void initializeFileTable() {
        if (this.con.getProgramStates().size() > 0) {
            ObservableList<FileTableDataFX> observable = FXCollections.observableArrayList();
            IFileTable<Integer, fileTuple> items = this.con.getRepo().getPrgList().get(0).getFileT();

            for (Integer key : items.getKeys())
                observable.add(new FileTableDataFX(key, items.get(key).getFileName()));

            identifier.setCellValueFactory(fileTableData -> fileTableData.getValue().identifierProperty().asObject());
            filename.setCellValueFactory(fileTableData -> fileTableData.getValue().filenameProperty());


            if (items != null && filetableTable != null)
                filetableTable.setItems(observable);
        }
    }
}
