package View;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class textMenu{
    public Map<String,Command> com;
    public textMenu()
    {
        com=new HashMap<>();
    }
    public void addCommand(Command c)
    {
        System.out.println("Ive put "+c.getKey()+" in the map");
        com.put(c.getKey(),c);

    }
    public void printMenu()
    {
        System.out.println("\n\n\n");
        for(Command c:com.values())
        {
            String line=String.format("%4s : %s", c.getKey(), c.getDescription());
            System.out.println(line);
        }
    }
    public void show()
    {
        Scanner sc=new Scanner(System.in);
        while(true)
        {
            printMenu();
            System.out.print("Input option: ");
            String inp=sc.nextLine();
            if(!com.containsKey(inp))
            {
                System.out.println("Wrong input!");
            }
            else
            {
                Command cm=com.get(inp);
                cm.execute();
            }

        }
    }
}
