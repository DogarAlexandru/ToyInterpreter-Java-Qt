package View;

import Controller.controller;
import model.*;
import model.Expression.ArithmeticExpr;
import model.Expression.ConstExpr;
import model.Expression.VarExpr;
import model.Statement.*;
import repository.*;
import utilities.*;

import java.util.Scanner;

public class view {
    public static void main(String arg[]) {
        /*Scanner sc=new Scanner(System.in);
        String inp;

        IStack<Statement> e=new ExecStack<>();
        IDictionary<String,Integer> d=new Dictionary<>();
        IList<Integer> l=new OutputList<>();
        IFileTable<Integer,fileTuple> ft=new FileTable<>();
        PrgState p ;
        IPrgStateRepo rep;
        controller con;
        Statement sf=new Statement.PrintStatement(new ConstExpr(3));



        System.out.println("Choose the Program you wish to \"input\" ;) :");
        System.out.println("1. v=2;Print(v) ");
        System.out.println("2. a=2+3*5;b=a+1;Print(b) ");
        System.out.println("3. a=2-2;\n" +
                "(If a Then v=2 Else v=3);\n" +
                " Print(v) ");
        System.out.print("Type here: ");
        inp=sc.nextLine();
        while (!inp.equals("1") && !inp.equals("2") && !inp.equals("3"))
        {
            System.out.println("Wrong input ");
            System.out.print("Type here: ");
            inp=sc.nextLine();
        }
        if(inp.equals("1"))
        {
            Statement s= new Statement.CompStatement(new Statement.AssignStatement("v",new ConstExpr(2)), new Statement.PrintStatement(new
                    VarExpr("v")));
            sf=s;

        }
        if(inp.equals("2"))
        {
            Statement s=new Statement.CompStatement(new Statement.AssignStatement("a", new ArithmeticExpr("+",new ConstExpr(2),new
                    ArithmeticExpr("*",new ConstExpr(3), new ConstExpr(5)))),
                    new Statement.CompStatement(new Statement.AssignStatement("b",new ArithmeticExpr("/",new VarExpr("a"), new
                            ConstExpr(0))), new Statement.PrintStatement(new VarExpr("b"))));

            sf=s;


        }
        if(inp.equals("3"))
        {
            Statement s=  new Statement.CompStatement(new Statement.AssignStatement("a", new ArithmeticExpr("-",new ConstExpr(2), new
                    ConstExpr(2))),
                    new Statement.CompStatement(new Statement.IfStatement(new VarExpr("a"),new Statement.AssignStatement("v",new ConstExpr(2)), new
                            Statement.AssignStatement("v", new ConstExpr(3))), new Statement.PrintStatement(new VarExpr("v"))));
            sf=s;


        }

       // p =new PrgState(e,d,l,sf,ft);
        rep=new PrgStateRepository("log.txt");
        rep.addPrgState(p);
        con=new controller(rep);

        System.out.println("Menu:");
        System.out.println("1.Eexecute 1 step");
        System.out.println("2.Execute whole program");
        System.out.println("3.Show program state");
        System.out.println("4.Exit");
        System.out.print("Type here: ");
        inp=sc.nextLine();
        while (!inp.equals("4") )
        {
            if(inp.equals("1"))
            {
                con.executeOneStep();
            }
            if(inp.equals("2"))
            {
                con.executeAll();
            }
            if(inp.equals("3"))
            {
                System.out.println(p);
            }
            System.out.print("Type here: ");
            inp=sc.nextLine();
        }




    }*/
    }
}
