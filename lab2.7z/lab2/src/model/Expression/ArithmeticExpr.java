package model.Expression;


import Exceptions.InterprException;
import model.Expression.Expression;
import utilities.IDictionary;
import utilities.IHeap;

public class ArithmeticExpr implements Expression {
    private String oper;
    private Expression left,right;
    public ArithmeticExpr(String o, Expression l, Expression r)
    {
        oper=o;
        left=l;
        right=r;
    }

    public int eval(IDictionary<String,Integer> di, IHeap<Integer,Integer> he)
    {
        int l=left.eval(di,he);
        int r=right.eval(di,he);
        if(oper.equals("+"))
        {
            return l+r;
        }
        if(oper.equals("-"))
        {
            return l-r;
        }
        if(oper.equals("*"))
        {
            return l*r;
        }
        if(oper.equals("/"))
        {
            if (r == 0) {
                throw new InterprException("Division by 0");
            } else {
                return l / r;
            }
        }
        throw new InterprException("Wrong operator");
    }

    @Override
    public String toString()
    {
        return " "+left+oper+right;
    }
}
