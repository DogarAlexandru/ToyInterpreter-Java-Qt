package model.Expression;

import Exceptions.InterprException;
import utilities.IDictionary;
import utilities.IHeap;

public class BooleanExpr implements Expression{

    private String oper;
    private Expression left,right;
    public BooleanExpr(String o, Expression l, Expression r)
    {
        oper=o;
        left=l;
        right=r;
    }


    @Override
    public int eval(IDictionary<String, Integer> di, IHeap<Integer, Integer> he) {
        int l=left.eval(di,he);
        int r=right.eval(di,he);
        if(oper.equals("<"))
        {
            if(l<r)
                return 1;
            return 0;
        }
        if(oper.equals("<="))
        {
            if(l<=r)
                return 1;
            return 0;
        }
        if(oper.equals(">="))
        {
            if(l>=r)
                return 1;
            return 0;
        }
        if(oper.equals(">"))
        {
            if(l>r)
                return 1;
            return 0;
        }
        if(oper.equals("=="))
        {
            if(l==r)
                return 1;
            return 0;
        }
        if(oper.equals("!="))
        {
            if(l!=r)
                return 1;
            return 0;
        }
        throw new InterprException("Wrong operator");
    }
    @Override
    public String toString()
    {
        return " "+left+oper+right;
    }
}
