package model.Expression;

import model.Expression.Expression;
import utilities.IDictionary;
import utilities.IHeap;

public class ConstExpr implements Expression {
    private int va;
    public ConstExpr(int n)
    {
        va=n;
    }
    public int eval(IDictionary<String,Integer> di, IHeap<Integer,Integer> he)
    {
        return va;
    }
    @Override
    public String toString()
    {
        return va+" ";
    }
}
