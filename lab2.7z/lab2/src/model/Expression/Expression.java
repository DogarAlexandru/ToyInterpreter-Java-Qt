package model.Expression;

import utilities.IDictionary;
import utilities.IHeap;

public interface Expression {
    public int eval(IDictionary<String,Integer> di, IHeap<Integer,Integer> he);
}
