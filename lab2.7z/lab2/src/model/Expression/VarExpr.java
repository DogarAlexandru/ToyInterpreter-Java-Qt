package model.Expression;

import Exceptions.InterprException;
import model.Expression.Expression;
import model.HeapStatement.rH;
import utilities.IDictionary;
import utilities.IHeap;

public class VarExpr implements Expression {
    private String name;
    public VarExpr(String s)
    {
        name=s;
    }
    public int eval(IDictionary<String,Integer> di, IHeap<Integer,Integer> he)
    {
        rH r=new rH(name);
        return r.eval(di,he);
    }

    @Override
    public String toString()
    {
        return " "+name;
    }
}
