package model.Expression;

import utilities.IDictionary;
import utilities.IHeap;

public class gt implements Expression {



    @Override
    public int eval(IDictionary<String, Integer> di, IHeap<Integer, Integer> he) {
        return 0;
    }
}
