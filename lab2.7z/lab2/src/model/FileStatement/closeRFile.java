package model.FileStatement;
import Exceptions.InterprException;
import model.Expression.Expression;
import model.PrgState;
import model.Statement.Statement;
import utilities.IFileTable;
import utilities.fileTuple;

import java.io.BufferedReader;
import java.io.IOException;

public class closeRFile implements Statement {
    private Expression ex;

    public closeRFile(Expression e)
    {
        ex=e;
    }

    @Override
    public PrgState execute(PrgState p) {
        int fid=ex.eval(p.getSymbolT(),p.getHeap());
        int asign;
        IFileTable<Integer,fileTuple> ft=p.getFileT();
        if(!ft.contains(fid))
        {
            throw new InterprException("The file is not in the filetable");
        }
        fileTuple tup=ft.getFileInfo(fid);
        BufferedReader bf=tup.getFileDescriptor();
        try {
            bf.close();

        }
        catch (IOException e)
        {
            throw new InterprException("Couldnt close file");
        }
        ft.remove(fid);
        return null;
    }
    @Override
    public String toString()
    {
        return "closeRFile("+ex+") ";
    }
}
