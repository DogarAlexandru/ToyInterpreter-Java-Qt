package model.FileStatement;


import Exceptions.InterprException;
import model.Expression.ConstExpr;
import model.HeapStatement.*;
import model.PrgState;
import model.Statement.Statement;
import utilities.IDictionary;
import utilities.IFileTable;
import utilities.fileTuple;
import utilities.idGenerator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class openRFile implements Statement {
    private String var;
    private String filename;

    public openRFile(String v,String fn)
    {
        var=v;
        filename=fn;
    }

    public PrgState execute(PrgState p){
        IFileTable<Integer,fileTuple> ft=p.getFileT();
        for(fileTuple t:ft.getValues())
        {
            if(t.getFileName().equals(filename))
            {
                throw new InterprException("File already open");
            }
        }

        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            fileTuple tup=new fileTuple(reader,filename);
            int id=idGenerator.generateId();
            ft.add(id,tup);
            IDictionary<String,Integer> dic=p.getSymbolT();
            if(dic.contains(var)) {
                wH a=new wH(var,new ConstExpr(id));
                a.execute(p);
            }
            else
            {
                newH n=new newH(var,new ConstExpr(id));
                n.execute(p);
            }
        }
        catch (IOException e)
        {
            throw new InterprException("Error pening file for operation");
        }
        return null;
    }
    @Override
    public String toString()
    {
        return "openRFile("+var+","+filename+") ";
    }
}
