package model.FileStatement;

import Exceptions.InterprException;
import model.Expression.ConstExpr;
import model.Expression.Expression;
import model.HeapStatement.newH;
import model.HeapStatement.wH;
import model.PrgState;
import model.Statement.Statement;
import utilities.IDictionary;
import utilities.IFileTable;
import utilities.fileTuple;

import java.io.BufferedReader;
import java.io.IOException;

public class readFile implements Statement {
    private Expression ex;
    private String vname;

    public readFile(Expression e,String s)
    {
        ex=e;
        vname=s;
    }

    @Override
    public PrgState execute(PrgState p) {
        int fid=ex.eval(p.getSymbolT(),p.getHeap());
        int asign;
        IFileTable<Integer,fileTuple> ft=p.getFileT();
        if(!ft.contains(fid))
        {
            throw new InterprException("The file is not in the filetable");
        }
        fileTuple tup=ft.getFileInfo(fid);
        BufferedReader bf=tup.getFileDescriptor();
        try {
            String val = bf.readLine();
            if(val==null)
            {
                asign=0;
            }
            else
            {
                asign=Integer.parseInt(val);
            }
            IDictionary<String,Integer> dic=p.getSymbolT();
            if(dic.contains(vname)) {
                wH a=new wH(vname,new ConstExpr(asign));
                a.execute(p);
            }
            else
            {
                newH n=new newH(vname,new ConstExpr(asign));
                n.execute(p);
            }

        }
        catch (IOException e)
        {
            throw new InterprException("Couldnt read from file");
        }
        return null;
    }
    @Override
    public String toString()
    {
        return "readFile("+ex+","+vname+") ";
    }
}
