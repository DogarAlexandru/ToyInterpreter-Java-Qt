package model.HeapStatement;

import model.Expression.Expression;
import model.PrgState;
import model.Statement.Statement;
import utilities.idGenerator;

public class newH implements Statement {
    private String name;
    private Expression ex;
    public newH(String n,Expression e)
    {
        this.name=n;
        this.ex=e;
    }


    @Override
    public PrgState execute(PrgState p) {
        int val=ex.eval(p.getSymbolT(),p.getHeap());
        int hid= idGenerator.generateId();
        p.getHeap().add(hid,val);
        if(p.getSymbolT().contains(name))
        {
            p.getSymbolT().update(name,hid);
        }
        else
        {
            p.getSymbolT().add(name,hid);
        }

        return null;
    }
    @Override
    public String toString()
    {
        return "newH("+name+" , "+ex+")";
    }
}
