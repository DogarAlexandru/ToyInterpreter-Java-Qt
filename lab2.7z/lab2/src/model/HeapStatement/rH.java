package model.HeapStatement;

import Exceptions.InterprException;
import model.Expression.Expression;
import model.PrgState;
import model.Statement.Statement;
import utilities.IDictionary;
import utilities.IHeap;

public class rH implements Expression {

    private String name;
    public rH(String n)
    {
        this.name=n;
    }


    @Override
    public String toString()
    {
        return "rH("+name+")";
    }

    @Override
    public int eval(IDictionary<String, Integer> di, IHeap<Integer, Integer> he) {
        if(!di.contains(name))
        {
            throw new InterprException("Variable is not in symbol table");
        }
        int adress=di.get(name);
        if(!he.contains(adress))
        {
            throw new InterprException("Variable is not alocated on heap");
        }

        return he.get(adress);
    }
}
