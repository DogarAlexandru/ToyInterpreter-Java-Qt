package model;

import Exceptions.InterprException;
import model.Statement.Statement;
import utilities.*;

public class PrgState {
    private IStack<Statement> execStack;
    private IDictionary<String,Integer> symbolT;
    private IList<Integer> messages;
    private IFileTable<Integer,fileTuple> fileT;
    private IHeap<Integer,Integer> heap;
    private Statement rootP;
    private int id;


    public PrgState(IStack<Statement> ex, IDictionary<String, Integer> dict, IList<Integer> mess, Statement stat,IFileTable<Integer,fileTuple> ft,IHeap<Integer,Integer> he)
    {
        execStack=ex;
        symbolT=dict;
        messages=mess;
        rootP=stat;
        fileT=ft;
        heap=he;
        //ex.push(rootP);
        id=idGenerator.generateId();
    }
    public void setStack(IStack<Statement> ex)
    {
        execStack=ex;
    }
    public void setSymbol(IDictionary<String,Integer> s)
    {
        symbolT=s;
    }
    public void setList(IList<Integer> m)
    {
        messages=m;
    }
    public void setStat(Statement r)
    {
        rootP=r;
    }
    public void setFileT(IFileTable<Integer, fileTuple> fileT) {
        this.fileT = fileT;
    }
    public void setHeap(IHeap<Integer,Integer> he){this.heap=he;}

    public IHeap<Integer,Integer> getHeap(){return heap;}
    public IStack<Statement> getExecStack() { return execStack; }
    public IDictionary<String,Integer> getSymbolT()
    {
        return symbolT;
    }
    public IList<Integer> getMessages()
    {
        return messages;
    }
    public Statement getStatement()
    {
        return rootP;
    }
    public IFileTable<Integer, fileTuple> getFileT() {
        return fileT;
    }
    public int getId(){return id;}

    public boolean isNotCompleted()
    {
        return ! execStack.isEmpty();
    }

    public PrgState executeOneStep()
    {
        if(execStack.isEmpty())
            throw new InterprException("The stack of execution is empty! PrgState:executeOneStep! id: " + id);
        try
        {
            Statement stmt = execStack.pop();
            return stmt.execute(this);
        }
        catch(InterprException ex)
        {
            System.out.println(ex.toString());
        }
        return null;
    }

    @Override
    public String toString()
    {
        StringBuffer b=new StringBuffer();
        b.append("ID: ");
        b.append(id);
        b.append("\n");
        b.append("ExecStack:\n");
        b.append(execStack);
        b.append("\n");
        b.append("SymbolTable:\n");
        b.append(symbolT);
        b.append("\n");
        b.append("Output:\n");
        b.append(messages);
        b.append("\n");
        return b.toString();
    }


}
