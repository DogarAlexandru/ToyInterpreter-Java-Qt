package model.Statement;

import model.Expression.Expression;
import model.HeapStatement.newH;
import model.PrgState;
import utilities.IDictionary;

public class AssignStatement implements Statement {
    private String name;
    private Expression val;
    public AssignStatement(String s,Expression in)
    {
        name=s;
        val=in;
    }

    public PrgState execute(PrgState p)
    {
        newH n=new newH(name,val);
        n.execute(p);

        return null;
    }

    @Override
    public String toString()
    {
        return name+" = "+val;
    }
}
