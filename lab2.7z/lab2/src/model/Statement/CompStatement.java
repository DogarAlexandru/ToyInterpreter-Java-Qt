package model.Statement;

import model.PrgState;

public class CompStatement implements Statement {
    private Statement left,right;
    public CompStatement(Statement l,Statement r)
    {
        left=l;
        right=r;
    }

    public PrgState execute(PrgState p){
        p.getExecStack().push(right);
        p.getExecStack().push(left);
        return null;
    }

    @Override
    public String toString()
    {
        return left+";\n "+right;
    }
}
