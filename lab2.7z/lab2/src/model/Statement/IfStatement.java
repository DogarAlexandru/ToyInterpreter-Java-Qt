package model.Statement;

import model.Expression.Expression;
import model.PrgState;

public class IfStatement implements Statement {
    private Expression cond;
    private Statement i,e;
    public IfStatement(Expression ex,Statement s1,Statement s2)
    {
        cond=ex;
        i=s1;
        e=s2;
    }

    public PrgState execute(PrgState p){
        int b=cond.eval(p.getSymbolT(),p.getHeap());
        if(b!=0){
            i.execute(p);
        }
        else {
            e.execute(p);
        }
        return null;
    }

    @Override
    public String toString()
    {
        return "If "+cond+" then "+i+" else "+e;
    }
}
