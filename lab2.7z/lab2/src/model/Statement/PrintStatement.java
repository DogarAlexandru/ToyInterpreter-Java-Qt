package model.Statement;

import model.Expression.Expression;
import model.PrgState;
import utilities.IDictionary;
import utilities.IList;

public class PrintStatement implements Statement {
    private Expression var;
    public PrintStatement(Expression s)
    {
        var=s;
    }

    public PrgState execute(PrgState p)
    {
        IDictionary<String,Integer> di=p.getSymbolT();

        int v=var.eval(p.getSymbolT(),p.getHeap());
        IList<Integer> o=p.getMessages();
        o.add(v);
        p.setList(o);

        return null;
    }

    @Override
    public String toString()
    {
        return "Print "+var;
    }
}
