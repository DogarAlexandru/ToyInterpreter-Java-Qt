package model.Statement;

import model.PrgState;

public class SleepStatement implements Statement {
    private int count;
    public SleepStatement(int c)
    {
        count=c;
    }


    public PrgState execute(PrgState p)
    {
        if(count>0)
        {
            p.getExecStack().push(new SleepStatement(count-1));
        }
        return null;
    }



    @Override
    public String toString()
    {
        return "sleep( "+count+" )";
    }
}
