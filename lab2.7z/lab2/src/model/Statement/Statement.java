package model.Statement;

import model.PrgState;

public interface Statement {
    public PrgState execute(PrgState p);

}
