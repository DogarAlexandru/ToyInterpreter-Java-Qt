package model.Statement;

import View.ExampleCommand;
import model.Expression.Expression;
import model.PrgState;

public class WhileStatement implements Statement {
    private Expression ex;
    private Statement st;
    public WhileStatement(Expression e,Statement s)
    {
        this.ex=e;
        this.st=s;
    }

    @Override
    public PrgState execute(PrgState p) {
        int val=ex.eval(p.getSymbolT(),p.getHeap());
        if(val!=0)
        {
            WhileStatement whi=new WhileStatement(ex,st);
            p.getExecStack().push(whi);
            p.getExecStack().push(st);
        }
        return null;
    }
    @Override
    public String toString()
    {
        return "while("+ex+") "+st;
    }
}
