package model.Statement;

import model.PrgState;
import utilities.*;

public class forkStatement implements Statement {
 private Statement st;
 public forkStatement(Statement stm)
 {
     st=stm;
 }
    @Override
    public PrgState execute(PrgState state) {
        IStack<Statement> newStack = new ExecStack<>();
        newStack.push(st);
        IDictionary<String,Integer> newDict = state.getSymbolT().copy();
        IList<Integer> outList = state.getMessages();
        IHeap<Integer,Integer> heap = state.getHeap();
        IFileTable<Integer,fileTuple> fileTable = state.getFileT();

        PrgState newState = new PrgState(newStack,newDict,outList,st,fileTable,heap);
        return newState;
    }
 @Override
 public String toString()
 {
    return "fork( "+st+" ) ";
 }
}
