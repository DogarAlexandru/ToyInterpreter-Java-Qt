package repository;

import model.PrgState;

import java.util.List;

public interface IPrgStateRepo {
    public void addPrgState(PrgState p);
    public PrgState getCurrentProgram();
    public void logPrgStateExec(PrgState ps);
    public List<PrgState> getPrgList();
    public void setPrgList(List<PrgState> lis);
}
