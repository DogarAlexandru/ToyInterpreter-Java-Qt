package repository;

import model.PrgState;
import model.Statement.Statement;
import utilities.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class PrgStateRepository implements IPrgStateRepo {
    private List<PrgState> l;
    private String fileName;
    public PrgStateRepository(String fl)
    {
        l=new ArrayList<>();
        fileName=fl;
    }

    public void addPrgState(PrgState p)
    {
        l.add(p);
    }
    public PrgState getCurrentProgram()
    {
        return l.get(0);
    }
    public void logPrgStateExec(PrgState ps) {
        try(PrintWriter wr = new PrintWriter(new BufferedWriter(new FileWriter(fileName,true))))
        {

            wr.println("ID: "+ps.getId());
            wr.println("Execution Stack:");
            IStack<Statement> ex=ps.getExecStack();
            for(Statement s:ex.getAll())
            {
                wr.println(s);
            }
            wr.println("\nSymbol Table:");
            IDictionary<String,Integer> di=ps.getSymbolT();
            for(String st:di.getKeys())
            {
                wr.println(st+" -> "+di.get(st));
            }
            wr.println("\nOutput List:");
            IList<Integer> lis=ps.getMessages();
            for(Integer i:lis.getAll())
            {
                wr.println(i);
            }
            wr.println("\nFileTable: ");
            IFileTable<Integer,fileTuple> ft=ps.getFileT();
            for(Integer i:ft.getKeys())
            {
                wr.println(i+" -> "+ft.get(i));
            }
            wr.println("\nHeap:");
            IHeap<Integer,Integer> he=ps.getHeap();
            for(Integer i:he.getAll())
            {
                wr.println(i+" -> "+he.get(i));
            }
            wr.println("\n------------------------------\n");

        }
        catch(IOException e)
        {
            System.out.println("Error opening file \n");
            return;
        }
    }
    public List<PrgState> getPrgList(){return l;}
    public void setPrgList(List<PrgState> lis){l=lis;}

}
