package utilities;
import java.util.*;


public class Dictionary<K,V> implements IDictionary<K,V> {
    private Map<K,V> dict;
    public Dictionary()
    {
        dict=new HashMap<>();

    }
    public void add(K key,V value)
    {
        dict.put(key,value);
    }
    public void update(K key,V value)
    {
        dict.put(key,value);
    }
    public boolean contains(K key)
    {
        return dict.containsKey(key);
    }
    public V get(K key)
    {
        return dict.get(key);
    }
    public Iterable<K> getKeys()
    {
        return dict.keySet();
    }

    @Override
    public Map<K, V> getContent() {
        return this.dict;
    }

    public IDictionary<K, V> copy() {
        IDictionary<K,V> newDict = new Dictionary<>();
        for(Map.Entry<K,V> entry : this.dict.entrySet())
        {
            newDict.add(entry.getKey(),entry.getValue());
        }
        return newDict;
    }

    @Override
    public String toString()
    {
        StringBuffer b =new StringBuffer();
        for(Map.Entry<K,V> d : dict.entrySet())
        {
            b.append(d.getKey());
            b.append(" ");
            b.append(d.getValue());
            b.append(" ");
        }
        return b.toString();
    }
    public void clear(){dict.clear();}

    public Set<Map.Entry<K, V>> entrySet()
    {
        return dict.entrySet();
    }
}
