package utilities;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;

public class ExecStack<T> implements IStack<T> {
    private Deque<T> stack;
    public ExecStack()
    {
        stack=new ArrayDeque<T>();
    }
    public void push(T x)
    {
        stack.push(x);
    }
    public T pop()
    {
        return stack.pop();
    }
    public boolean isEmpty()
    {
        return stack.size()==0;
    }
    public Iterable<T> getAll(){return stack;}
    @Override
    public String toString()
    {
        StringBuffer b=new StringBuffer();
        for(T i : stack)
        {
            b.append(i);
            b.append(" ");
        }
        return b.toString();
    }
    public void clear(){this.stack.clear();}
}
