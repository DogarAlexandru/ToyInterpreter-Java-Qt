package utilities;

import java.util.*;

public class FileTable<K,V> implements IFileTable<K,V> {
    private Map<K,V> fileTable;
    public FileTable()
    {
        fileTable=new HashMap<>();
    }
    public void add(K key,V value)
    {
        fileTable.put(key,value);
    }
    public Iterable<V> getValues()
    {
        return fileTable.values();
    }
    public V getFileInfo(K key)
    {
        return fileTable.get(key);
    }
    public boolean contains(K key)
    {
        return fileTable.containsKey(key);
    }
    public Iterable<K> getKeys(){return fileTable.keySet();}
    public V get(K key){return fileTable.get(key);}
    public void remove(K key){fileTable.remove(key);}

    @Override
    public Set<Map.Entry<K, V>> getContent() {
        return fileTable.entrySet();
    }

    @Override
    public String toString()
    {
        StringBuffer b=new StringBuffer();
        for(Map.Entry<K,V> m:fileTable.entrySet())
        {
            b.append(m.getKey().toString());
            b.append(" -> ");
            b.append(m.getValue().toString());
            b.append("\n");
        }
        return b.toString();
    }
    public void clear(){fileTable.clear();}
}
