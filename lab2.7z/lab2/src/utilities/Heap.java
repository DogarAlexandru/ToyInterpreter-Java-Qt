package utilities;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Heap<K,V> implements IHeap<K,V> {
    private Map<K,V> dict;
    public Heap()
    {
        dict=new HashMap<>();
    }

    @Override
    public String toString()
    {
        StringBuffer b =new StringBuffer();
        for(Map.Entry<K,V> d : dict.entrySet())
        {
            b.append(d.getKey());
            b.append(" ");
            b.append(d.getValue());
            b.append(" ");
        }
        return b.toString();
    }

    @Override
    public void add(K key, V val) {
        dict.put(key,val);
    }

    @Override
    public V get(K key) {
        return dict.get(key);
    }

    @Override
    public boolean contains(K key) {
        return dict.containsKey(key);
    }

    @Override
    public Iterable<K> getAll() {
        return dict.keySet();
    }

    @Override
    public void update(K key, V val) {
        dict.put(key,val);
    }

    @Override
    public Map<K, V> getContent() {
        return this.dict;
    }

    @Override
    public void setContent(Map<K, V> newH) {
            this.dict=newH;
    }

    public void clear(){dict.clear();}

    public Set<Map.Entry<K, V>> entrySet()
    {
        return dict.entrySet();
    }

}
