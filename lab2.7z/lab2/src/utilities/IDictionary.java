package utilities;

import java.util.Map;
import java.util.Set;

public interface IDictionary <K,V> {

    public void add(K key,V value);
    public void update(K key,V value);
    public boolean contains(K key);
    public V get(K key);
    public Iterable<K> getKeys();
    public Map<K,V> getContent();
    public IDictionary<K,V> copy();
    public void clear();
    public Set<Map.Entry<K, V>> entrySet();

}
