package utilities;

import java.util.Map;
import java.util.Set;

public interface IFileTable<K,V> {
    public void add(K key,V value);
    public Iterable<V> getValues();
    public V getFileInfo(K key);
    public boolean contains(K key);
    public Iterable<K> getKeys();
    public V get(K key);
    public void remove(K key);
    public Set<Map.Entry<K, V>> getContent();
    public void clear();

}
