package utilities;

public interface IStack<T> {
    public void push(T x);
    public T pop();
    public boolean isEmpty();
    public Iterable<T> getAll();
    public void clear();


}
