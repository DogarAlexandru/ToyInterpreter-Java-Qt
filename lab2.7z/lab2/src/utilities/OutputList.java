package utilities;

import java.util.ArrayList;
import java.util.List;

public class OutputList<T> implements IList<T> {
    private List<T> l;
    public OutputList()
    {
        l=new ArrayList<>();
    }
    public void add(T x)
    {
        l.add(x);
    }
    public Iterable<T> getAll()
    {
        return l;
    }
    @Override
    public String toString()
    {
        StringBuffer b=new StringBuffer();
        for(T x : l)
        {
            b.append(x);
            b.append(" ");
        }
        return b.toString();
    }

    public void clear(){l.clear();}

}
