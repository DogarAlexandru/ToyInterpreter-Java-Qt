package utilities;

import java.io.BufferedReader;

public class fileTuple {

    private String fileName;
    private BufferedReader fileDescriptor;
    public fileTuple(BufferedReader b, String fn)
    {
        fileDescriptor=b;
        fileName=fn;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public BufferedReader getFileDescriptor() {
        return fileDescriptor;
    }

    public void setFileDescriptor(BufferedReader fileDescriptor) {
        this.fileDescriptor = fileDescriptor;
    }
    @Override
    public String toString()
    {
        return fileName;
    }


}
