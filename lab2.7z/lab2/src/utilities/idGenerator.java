package utilities;

public class idGenerator {
    private static int id = 1;
    public static int generateId()
    {
        return id++;
    }
}
